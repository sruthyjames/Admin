import './Admin.css';
import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Navbar, Nav, NavDropdown } from 'react-bootstrap'


function Admin() {
  return (
    <div>
    <Navbar bg="light" variant="light" expand="lg">
      
      <div className="header">
      <Navbar.Brand href="#home"><img className="logo" src="src\assets\logo Nav.png" alt="Logo"/> 
      Parcel Service</Navbar.Brand>
      </div>
      
      <Navbar.Toggle aria-controls="basic-navbar-nav" />
      <Navbar.Collapse id="basic-navbar-nav" className="d-flex justify-content-end">
        <Nav className="mr-auto">
          <Nav.Link href="#Home" className="navlist">Home</Nav.Link>
          {/* <Nav.Link href="#About">About</Nav.Link> */}
          <NavDropdown title="Service" id="basic-nav-dropdown">
            
            <NavDropdown.Item href="#View Parcel">View Parcel</NavDropdown.Item>
            <NavDropdown.Item href="#Search Parcel">Search Parcel</NavDropdown.Item>
          </NavDropdown>
          <Nav.Link href="#Logout">Logout</Nav.Link>
        </Nav>
      </Navbar.Collapse>
    </Navbar>
    

   {/* <div className="row">

    </div>
    <div className="two-column">
      <div className="column">
        
      </div>
      <div className="column">
       
      </div>
  </div> */}
  <div className="image">
      <img src=".\src\assets\User-Icon-Grey.png" alt="Admin login" />
      <p className="logo-text">Admin</p>
    <div className="view">
      <button type="button">View Parcel</button>
    </div>
    <div className="search">
    <button type="button">Search User</button>
    </div>
    </div>


    </div>
    
  )
 

}

export default Admin